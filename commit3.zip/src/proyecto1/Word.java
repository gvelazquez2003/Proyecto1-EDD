package proyecto1;

public class Word {
    String word;
    boolean found = false;
    float time = 0;
    
    public Word(String word){
        this.word = word;
    }
}
